import React, {useState} from "react"
import {ModalHeader, ModalBody, ModalFooter, Button, Form, FormGroup, Label, Input} from "reactstrap"
import axios from "axios"
import {toast} from "react-toastify"

const SignUpForm = ({toggleIsLogin, toggle}) => {
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = () => {
    axios({
      method: 'POST',
      url: 'https://insta.nextacademy.com/api/v1/users/',
      data: {
        username: username,
        email: email,
        password: password
      }
    })
    .then(response => {
      console.log(response)
      toast(response.data.message, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        });
    })
    .catch(error => {

      error.response.data.message.forEach((message) => {
        toast.error(message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      })

      console.error(error.response) // so that we know what went wrong if the request failed
    })
  }

  return <>
    <Form>
      <ModalHeader toggle={toggle}>Sign Up</ModalHeader>
      <ModalBody>
          <FormGroup>
            <Label for="username">Username</Label>
            <Input type="username" name="username" id="username" placeholder="Key in username" value={username} onChange={(e)=>{setUsername(e.target.value)}}/>
          </FormGroup>
          <FormGroup>
            <Label for="email">Email</Label>
            <Input type="email" name="email" id="email" placeholder="Key in email" value={email} onChange={(e)=>{setEmail(e.target.value)}} />
          </FormGroup>
          <FormGroup>
            <Label for="password">Password</Label>
            <Input type="password" name="password" id="password" placeholder="Key in password" value={password} onChange={(e)=>{setPassword(e.target.value)}} />
          </FormGroup>
          <p>Already a member? <a href="#" onClick ={(e) =>{
            e.preventDefault()
            toggleIsLogin()
          }}>Log in here</a></p>
      </ModalBody>
      <ModalFooter>
        <Button 
          color="primary" 
          disabled={!(username && email && password)} 
          onClick={handleSubmit}>Sign Up</Button>{' '}
        <Button color="secondary" onClick={toggle}>Cancel</Button>
      </ModalFooter>
    </Form>
  </>
}

export default SignUpForm