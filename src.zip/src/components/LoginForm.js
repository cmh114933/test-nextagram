import React, {useState} from "react"
import {ModalHeader, ModalBody, ModalFooter, Button, Form, FormGroup, Label, Input} from "reactstrap"

const LoginForm = ({toggleIsLogin, toggle}) => {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  return <>
    <Form>
      <ModalHeader toggle={toggle}>Log In</ModalHeader>
      <ModalBody>
          <FormGroup>
            <Label for="username">Username</Label>
            <Input type="username" name="username" id="username" placeholder="username" value={username}  onChange={(e) => {setUsername(e.target.value)}}/>
          </FormGroup>
          <FormGroup>
            <Label for="password">Password</Label>
            <Input type="password" name="password" id="password" placeholder="password" value={password} onChange={(e) => {setPassword(e.target.value)}}/>
          </FormGroup>
          <p>New member? <a href="#" onClick ={(e) =>{
            e.preventDefault()
            toggleIsLogin()
          }}>Sign up here</a></p>
      </ModalBody>
      <ModalFooter>
        <Button color="primary" onClick={() => {}}>Log In</Button>{' '}
        <Button color="secondary" onClick={toggle}>Cancel</Button>
      </ModalFooter>
    </Form>
  </>
  
}


export default LoginForm