import React, { useState } from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink
} from 'reactstrap';
import {useHistory} from 'react-router-dom'
import AuthModal from "./AuthModal"

const NavBarDisplay = () => {
    const [isOpen, setIsOpen] = useState(false);
    const history = useHistory()

    const toggle = () => setIsOpen(!isOpen);

    const [showModal, setShowModal] = useState(false)
    const toggleModal = () => {
        setShowModal(!showModal)
    }

    return (
    <div>
        <Navbar color="dark" dark expand="md">
            <NavbarBrand style={{cursor:"pointer"}} onClick= {() => {history.push("/")}}>Nextagram</NavbarBrand>
            <NavbarToggler onClick={toggle} />
            <Collapse isOpen={isOpen} navbar>
                <Nav className="ml-auto" navbar>
                    <NavItem>
                        <NavLink style={{cursor:"pointer"}} onClick= {() => {history.push("/")}}>Home</NavLink>
                    </NavItem>
                    <NavItem>
                        <NavLink style={{cursor:"pointer"}} onClick= {toggleModal}>Log In</NavLink>
                    </NavItem>
                    {/* <NavItem>
                        <NavLink href="https://github.com/reactstrap/reactstrap">GitHub</NavLink>
                    </NavItem> */}

                </Nav>
            </Collapse>
        </Navbar>
        <AuthModal 
            isOpen={showModal} 
            toggle={toggleModal}
        />
    </div>
    );

}

export default NavBarDisplay